# Sales Random Forest — Final UAS Dashboard

Frontend final untuk proyek Machine Learning berbasis CRISP-DM.

## Fitur
- Prediksi kategori produk
- Confidence dan Top-5 probability
- Statistik dataset
- Grafik distribusi kategori
- Data quality
- Classification report
- Confusion matrix
- Ringkasan CRISP-DM
- Memuat `sales_model.pkl` tanpa training ulang

## Struktur yang disarankan

```text
sales_random_forest/
├── app.py
├── sales_model.pkl
├── requirements.txt
├── metrics.json
├── classification_report.txt
├── confusion_matrix.csv
├── CRISP_DM_Sales_Random_Forest.ipynb
└── data/
    └── annex1_cleaned_preprocessed.csv
```

## Jalankan lokal

```bash
pip install -r requirements.txt
streamlit run app.py
```
