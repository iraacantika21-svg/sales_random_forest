# Sales Category Predictor — Random Forest + TF-IDF

## Menjalankan aplikasi

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Isi project
- `app.py` — dashboard Streamlit
- `sales_model.pkl` — model Random Forest + TF-IDF
- `sales_model.pkt` — salinan model
- `annex1_cleaned_preprocessed.csv` — dataset
- `metrics.json` — metrik evaluasi
- `classification_report.txt` — classification report
- `confusion_matrix.csv` — confusion matrix
- `requirements.txt` — dependency

Model sudah dilatih sebelumnya. Aplikasi hanya memuat model dan **tidak melakukan training ulang saat startup**.
