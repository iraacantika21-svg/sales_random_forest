
import streamlit as st
import pandas as pd
import numpy as np
import pickle
from pathlib import Path

# =========================================================
# CONFIG
# =========================================================
st.set_page_config(
    page_title="Sales Category Predictor",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

MODEL_PATH = Path("sales_model.pkl")

# =========================================================
# CUSTOM CSS
# =========================================================
st.markdown("""
<style>
    .stApp {
        background: #f6f8fb;
    }
    .block-container {
        padding-top: 2rem;
        padding-bottom: 3rem;
        max-width: 1250px;
    }
    [data-testid="stSidebar"] {
        background: #111827;
        border-right: 1px solid #1f2937;
    }
    [data-testid="stSidebar"] * {
        color: #e5e7eb !important;
    }
    .hero {
        padding: 2rem 2.2rem;
        border-radius: 22px;
        background: linear-gradient(135deg, #111827 0%, #1f2937 55%, #374151 100%);
        color: white;
        margin-bottom: 1.5rem;
        box-shadow: 0 12px 35px rgba(17,24,39,.15);
    }
    .hero h1 {
        font-size: 2.35rem;
        margin: 0 0 .45rem 0;
        font-weight: 800;
        letter-spacing: -.04em;
    }
    .hero p {
        margin: 0;
        color: #d1d5db;
        font-size: 1.02rem;
    }
    .section-title {
        font-size: 1.25rem;
        font-weight: 750;
        color: #111827;
        margin: 1.2rem 0 .8rem;
    }
    .metric-card {
        background: white;
        border: 1px solid #e5e7eb;
        border-radius: 16px;
        padding: 1rem 1.1rem;
        box-shadow: 0 5px 18px rgba(15,23,42,.05);
    }
    .metric-label {
        color: #6b7280;
        font-size: .82rem;
        font-weight: 650;
        text-transform: uppercase;
        letter-spacing: .04em;
    }
    .metric-value {
        color: #111827;
        font-size: 1.55rem;
        font-weight: 800;
        margin-top: .2rem;
    }
    .result-card {
        background: white;
        border: 1px solid #e5e7eb;
        border-radius: 20px;
        padding: 1.5rem;
        box-shadow: 0 8px 28px rgba(15,23,42,.07);
    }
    .result-label {
        color: #6b7280;
        font-size: .82rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: .06em;
    }
    .result-category {
        color: #111827;
        font-size: 2rem;
        font-weight: 850;
        margin: .35rem 0;
    }
    .confidence {
        color: #374151;
        font-size: 1rem;
    }
    .tip {
        background: #eef2ff;
        border: 1px solid #c7d2fe;
        border-radius: 14px;
        padding: .9rem 1rem;
        color: #3730a3;
        font-size: .92rem;
    }
    .footer {
        text-align: center;
        color: #9ca3af;
        padding-top: 2rem;
        font-size: .82rem;
    }
</style>
""", unsafe_allow_html=True)

# =========================================================
# HELPERS
# =========================================================
@st.cache_resource
def load_model():
    if not MODEL_PATH.exists():
        return None
    with open(MODEL_PATH, "rb") as f:
        return pickle.load(f)

def predict_model(model, text):
    """Supports a normal sklearn Pipeline/model and common exported formats."""
    x = [text]

    # sklearn Pipeline / estimator
    if hasattr(model, "predict"):
        pred = model.predict(x)[0]
        probs = None
        if hasattr(model, "predict_proba"):
            probs = model.predict_proba(x)[0]
            classes = getattr(model, "classes_", None)
            if classes is None and hasattr(model, "named_steps"):
                final_step = list(model.named_steps.values())[-1]
                classes = getattr(final_step, "classes_", None)
        else:
            classes = getattr(model, "classes_", None)
        return pred, probs, classes

    # exported dict: {"vectorizer": ..., "model": ...}
    if isinstance(model, dict):
        vectorizer = model.get("vectorizer") or model.get("tfidf")
        estimator = model.get("model") or model.get("classifier") or model.get("rf")
        if vectorizer is not None and estimator is not None:
            X = vectorizer.transform(x)
            pred = estimator.predict(X)[0]
            probs = estimator.predict_proba(X)[0] if hasattr(estimator, "predict_proba") else None
            classes = getattr(estimator, "classes_", None)
            return pred, probs, classes

    # exported tuple/list: (vectorizer, model)
    if isinstance(model, (tuple, list)) and len(model) >= 2:
        vectorizer, estimator = model[0], model[1]
        X = vectorizer.transform(x)
        pred = estimator.predict(X)[0]
        probs = estimator.predict_proba(X)[0] if hasattr(estimator, "predict_proba") else None
        classes = getattr(estimator, "classes_", None)
        return pred, probs, classes

    raise TypeError("Format model tidak dikenali. Gunakan sklearn Pipeline atau dict/tuple berisi vectorizer + model.")

# =========================================================
# SIDEBAR
# =========================================================
with st.sidebar:
    st.markdown("## 📊 Sales AI")
    st.caption("Random Forest Classification")
    st.divider()

    st.markdown("### Model")
    st.success("● Model loaded" if MODEL_PATH.exists() else "● Model belum ditemukan")

    st.markdown("**Algorithm**  \nRandom Forest")
    st.markdown("**Features**  \nTF-IDF dari nama produk")
    st.markdown("**Estimators**  \n400 trees")

    st.divider()
    st.markdown("### Navigasi")
    st.markdown("🏠 **Prediction**")
    st.markdown("📈 **Model Performance**")
    st.markdown("ℹ️ **About**")

    st.divider()
    st.caption("Built with Streamlit • Machine Learning")

# =========================================================
# HERO
# =========================================================
st.markdown("""
<div class="hero">
    <h1>Sales Category Predictor</h1>
    <p>Prediksi kategori produk secara cepat menggunakan model Random Forest berbasis TF-IDF.</p>
</div>
""", unsafe_allow_html=True)

# =========================================================
# KPI
# =========================================================
kpis = [
    ("Accuracy", "90.20%"),
    ("Precision", "92.20%"),
    ("Recall", "90.20%"),
    ("F1 Score", "90.26%"),
]
cols = st.columns(4)
for col, (label, value) in zip(cols, kpis):
    with col:
        st.markdown(
            f'<div class="metric-card"><div class="metric-label">{label}</div>'
            f'<div class="metric-value">{value}</div></div>',
            unsafe_allow_html=True
        )

st.markdown('<div class="section-title">🔎 Product Prediction</div>', unsafe_allow_html=True)

# =========================================================
# INPUT
# =========================================================
left, right = st.columns([1.35, .65], gap="large")

with left:
    st.markdown("#### Enter product name")
    product_name = st.text_input(
        "Product",
        placeholder="Contoh: Red Bell Pepper (Bag)",
        label_visibility="collapsed",
    )

    examples = [
        "Red Bell Pepper (Bag)",
        "Needle Mushroom (Bag)",
        "Chinese Cabbage",
        "Broccoli",
        "Spinach",
    ]

    selected = st.pills("Quick examples", examples, selection_mode="single")
    if selected and not product_name:
        product_name = selected

with right:
    st.markdown("#### Prediction settings")
    st.info(
        "Masukkan nama produk seperti yang biasa muncul pada katalog. "
        "Model akan mengembalikan kategori dan probabilitas prediksi."
    )

model = load_model()

if not MODEL_PATH.exists():
    st.error(
        "File `sales_model.pkl` belum ada di repository. "
        "Upload file model tersebut ke folder yang sama dengan `app.py`."
    )
elif product_name.strip():
    st.markdown('<div class="section-title">✨ Prediction Result</div>', unsafe_allow_html=True)

    try:
        pred, probs, classes = predict_model(model, product_name.strip())

        if probs is not None and classes is not None:
            order = np.argsort(probs)[::-1]
            top_n = min(5, len(order))
            labels = [str(classes[i]) for i in order[:top_n]]
            values = [float(probs[i]) * 100 for i in order[:top_n]]
            confidence = values[0]

            c1, c2 = st.columns([1, 1.35], gap="large")

            with c1:
                st.markdown(
                    f"""
                    <div class="result-card">
                        <div class="result-label">Predicted category</div>
                        <div class="result-category">{pred}</div>
                        <div class="confidence">Confidence: <b>{confidence:.2f}%</b></div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )

            with c2:
                chart_df = pd.DataFrame({
                    "Category": labels[::-1],
                    "Probability (%)": values[::-1],
                }).set_index("Category")
                st.bar_chart(chart_df, horizontal=True)

            st.markdown("#### Probability breakdown")
            table_df = pd.DataFrame({
                "Category": labels,
                "Probability": [f"{v:.2f}%" for v in values],
            })
            st.dataframe(table_df, use_container_width=True, hide_index=True)

        else:
            st.success(f"Predicted category: **{pred}**")
            st.caption("Model tidak menyediakan `predict_proba`, sehingga confidence tidak ditampilkan.")

    except Exception as e:
        st.error("Prediksi gagal.")
        st.code(str(e))

elif product_name == "":
    st.markdown(
        '<div class="tip">💡 Masukkan nama produk atau pilih salah satu contoh untuk memulai prediksi.</div>',
        unsafe_allow_html=True
    )

# =========================================================
# MODEL PERFORMANCE
# =========================================================
st.markdown('<div class="section-title">📈 Model Performance</div>', unsafe_allow_html=True)

perf1, perf2 = st.columns(2, gap="large")

with perf1:
    st.markdown("#### Evaluation metrics")
    perf_df = pd.DataFrame({
        "Metric": ["Accuracy", "Precision", "Recall", "F1 Score"],
        "Score": [90.20, 92.20, 90.20, 90.26],
    })
    st.dataframe(
        perf_df.assign(Score=perf_df["Score"].map(lambda x: f"{x:.2f}%")),
        use_container_width=True,
        hide_index=True,
    )

with perf2:
    st.markdown("#### Model information")
    info_df = pd.DataFrame({
        "Property": ["Algorithm", "Vectorization", "Trees", "Target", "Test samples"],
        "Value": ["Random Forest", "TF-IDF", "400", "Category Name", "51"],
    })
    st.dataframe(info_df, use_container_width=True, hide_index=True)

# =========================================================
# ABOUT
# =========================================================
with st.expander("ℹ️ About this application"):
    st.write(
        "Aplikasi ini menggunakan TF-IDF untuk merepresentasikan nama produk "
        "menjadi fitur numerik, kemudian Random Forest melakukan klasifikasi "
        "ke kategori produk."
    )
    st.write(
        "Model yang digunakan merupakan model yang sudah dilatih sebelumnya. "
        "Upgrade ini hanya memperbarui antarmuka Streamlit dan tidak mengubah model."
    )

st.markdown(
    '<div class="footer">Sales Random Forest • Professional Dashboard</div>',
    unsafe_allow_html=True,
)
