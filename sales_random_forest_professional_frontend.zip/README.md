# Sales Random Forest — Professional Frontend

Frontend Streamlit yang diperbarui untuk repository `sales_random_forest`.

## File
- `app.py` — frontend/dashboard baru
- `requirements.txt` — dependency Streamlit
- `README.md` — panduan singkat

## Cara update GitHub
1. Buka repository `sales_random_forest`.
2. Pilih **Add file → Upload files**.
3. Upload `app.py` dan `requirements.txt`.
4. Commit changes.
5. Streamlit Cloud akan melakukan redeploy otomatis.

## Catatan
Model tidak diubah. Pastikan `sales_model.pkl` tetap berada di root repository.
